# 杭州西子湖 · 今夕入画 V7

这是完整静态交付包。完整解压后，使用 Node.js 22+ 运行 `node start-preview.mjs`，在浏览器打开 http://127.0.0.1:4174/ 。Windows 可双击「启动预览.cmd」。请勿直接双击 HTML。

首页点击「一湖三境」开始六幕导览；也可直接点选十景、湖山寻路或乌龟潭。首次操作后播放古琴长曲《平沙落雁》与解说，湖声设置可分别关闭；切换景点时音乐连续播放。古琴录音由 Charlie Huang 演奏，按 CC BY 2.5 使用，公开展示时须保留署名。手机次级控制位于「游湖工具」。

部署时将 index.html、styles.css、src、assets 放到静态网站根目录；本地启动脚本不需要上传。

交付记录见 [docs/v7-delivery.md](docs/v7-delivery.md)，配乐授权与验证见 [docs/research/2026-11-12-music-v7.md](docs/research/2026-11-12-music-v7.md)，作品阐述与现场演示顺序见 [docs/competition-note.md](docs/competition-note.md)。这里是静态运行包，不含开发用测试脚本；验收结果在交付记录中列明。
